E1.b
